# WebRTC Example
=============

This is a web application that allows you to video chat with someone else.
Just create a virtual room, share the link with someone and start a video chat.
The application also supports traditional web chat using text messages.

Written using JavaScript and Erlang.

### Tested with browsers

  - Firefox version 22 or later
  - Google Chrome version 23 or later

## This repository is a bit outdated, and contains client part only. The server part can be found in a separate repo: https://github.com/Oslikas/WebRTCO

